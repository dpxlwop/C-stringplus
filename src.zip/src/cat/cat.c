#include "cat.h"

#include <getopt.h>
#include <stdio.h>

#define MAX_LENGTH_STRING 1024

// спец структура позволяющая определять длинные опции и их атрибуты
// имя опции, требует ли опция агрумент, указатель на переменную куда
// устанавливается знач. опции, значение которое возврашается
struct option long_options[] = {{"number-nonblank", no_argument, 0, 'b'},
                                {"number", no_argument, 0, 'n'},
                                {"squeeze-blank", no_argument, 0, 's'},
                                {0, 0, 0, 0}};

int main(int argc, char *argv[]) {
  flags flag_container = {0};

  if (argc < 2) {
    fprintf(stderr, "Incorrect number of arguments");
    return 1;
  }

  int res = 0;
  while ((res = getopt_long(argc, argv, "+benstvET", long_options, NULL)) !=
         -1) {
    if (switch_cases(res, &flag_container) != 0) {
      return 1;
    }
  }

  if (flag_container.b && flag_container.n) flag_container.n = 0;

  for (int i = optind; i < argc; i++) {
    file_handling(argv[i], flag_container);
  }

  return 0;
}

int switch_cases(int res, flags *flag_container) {
  switch (res) {
    case 'b':
      flag_container->b = 1;
      break;
    case 'e':
      flag_container->e = 1;
      flag_container->v = 1;
      break;
    case 'E':
      flag_container->e = 1;
      break;
    case 'n':
      flag_container->n = 1;
      break;
    case 's':
      flag_container->s = 1;
      break;
    case 't':
      flag_container->t = 1;
      flag_container->v = 1;
      break;
    case 'T':
      flag_container->t = 1;
      break;
    case 'v':
      flag_container->v = 1;
      break;
    default:
      fprintf(stderr, "Unknown flag");
      return 1;
  }
  return 0;
}

int file_handling(const char *filename, flags flag_container) {
  FILE *file = fopen(filename, "rb");
  if (!file) {
    fprintf(stderr, "error reading the file");
    return 1;
  }

  int c;
  int consecutive_empty = 0;
  int line_number = 1;
  int at_start_line = 1;       // флаг на начало строки
  int current_line_empty = 1;  // флаг на пустую строку

  while ((c = fgetc(file)) != EOF) {
    unsigned char uc = (unsigned char)c;

    if (flag_container.s) {
      if (flag_s(at_start_line, uc, &consecutive_empty)) continue;
    }

    if (at_start_line) {
      flag_bn(&line_number, uc, flag_container, &at_start_line,
              &current_line_empty);
    }

    if (uc == '\n') {
      if (flag_container.e && flag_container.b && current_line_empty) {
        printf("      	$\n");
      } else if (flag_container.e) {
        printf("$\n");
      } else {
        printf("\n");
      }
      at_start_line = 1;
      current_line_empty = 1;
    } else {
      print_special_char(uc, flag_container);
      current_line_empty = 0;
    }
  }
  fclose(file);
  return 0;
}

int flag_s(int at_start_line, int uc, int *consecutive_empty) {
  int op = 0;
  if (at_start_line && uc == '\n') {
    (*consecutive_empty)++;
    if (*consecutive_empty > 1) {
      op = 1;
    }
  } else if (at_start_line && uc != '\n') {
    *consecutive_empty = 0;
  }
  return op;
}

void flag_bn(int *line_number, int uc, flags flag_container, int *at_start_line,
             int *current_line_empty) {
  if (flag_container.n) {
    printf("%6d\t", (*line_number)++);

  } else if (flag_container.b && uc != '\n') {
    printf("%6d\t", (*line_number)++);
  }

  *at_start_line = 0;
  *current_line_empty = (uc == '\n');
}

void tab_hand(int c, flags flag_container) {
  if (flag_container.t) {
    printf("^I");
  } else {
    putchar(c);
  }
}

void control_hand(int c, flags flag_container) {
  if (flag_container.v) {
    printf("^%c", c + 64);
  } else {
    putchar(c);
  }
}

void del_hand(int c, flags flag_container) {
  if (flag_container.v) {
    printf("^?");
  } else {
    putchar(c);
  }
}

void ascii1_hand(int c, flags flag_container) {
  if (flag_container.v) {
    printf("M-^%c", c - 64);
  } else {
    putchar(c);
  }
}

void ascii2_hand(int c, flags flag_container) {
  if (flag_container.v) {
    if (c == 255) {
      printf("M-^?");
    } else {
      printf("M-%c", c - 128);
    }
  } else {
    putchar(c);
  }
}

void print_special_char(int c, flags flag_container) {
  if (!flag_container.v && !flag_container.t) {
    putchar(c);
    return;
  }
  if (c == 9) {
    tab_hand(c, flag_container);

  } else if (c < 32 && c != 10) {
    control_hand(c, flag_container);

  } else if (c < 127) {
    putchar(c);

  } else if (c == 127) {
    del_hand(c, flag_container);

  } else if (c < 160) {
    ascii1_hand(c, flag_container);

  } else if (c <= 255) {
    ascii2_hand(c, flag_container);
  } else {
    putchar(c);
  }
}
