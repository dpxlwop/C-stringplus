typedef struct {
  int b;
  int e;
  int n;
  int s;
  int t;
  int v;
} flags;

int file_handling(const char *filename, flags flag_container);
void print_special_char(int c, flags flag_container);
int switch_cases(int res, flags *flag_container);
int flag_s(int at_start_line, int uc, int *consecutive_empty);
void flag_bn(int *line_number, int uc, flags flag_container, int *at_start_line,
             int *current_line_empty);
void tab_hand(int c, flags flag_container);
void control_hand(int c, flags flag_container);
void del_hand(int c, flags flag_container);
void ascii1_hand(int c, flags flag_container);
void ascii2_hand(int c, flags flag_container);