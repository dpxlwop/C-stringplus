typedef struct {
  int e;
  int i;
  int v;
  int c;
  int l;
  int n;
  // int h;
  // int s;
  // int f;
  // int o;
} flags;

int file_handling(const char* filename, char** patterns, int pattern_count,
                  flags flag_container, int file_count);
char** parse_templates(char** patterns, int* count_templates,
                       char* pattern_value);
void free_memory(char** patterns, int count_templates);
int find_string(char* line, char* template, flags flag_container);
void output(flags flag_container, char* line, char* filename, int file_number,
            int line_number);
void output_cl(flags flag_container, char* filename, int file_number,
               int match_count);