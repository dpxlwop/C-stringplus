#include "grep.h"

#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LENGHT_STRING 1024

int main(int argc, char *argv[]) {
  flags flag_container = {0};
  int count_templates = 0, res = 0;
  char **patterns = calloc(1, sizeof(char *));
  if (patterns == NULL) {
    fprintf(stderr, "Memory allocation failed\n");
    return 1;
  }
  if (argc < 2) {
    fprintf(stderr, "Incorrect number of arguments\n");
    free(patterns);
    return 1;
  }
  while ((res = getopt_long(argc, argv, "e:ivcln", NULL, NULL)) != -1) {
    switch (res) {
      case 'e':
        flag_container.e = 1;
        patterns = parse_templates(patterns, &count_templates, optarg);
        if (patterns == NULL) return 1;
        break;
      case 'i':
        flag_container.i = 1;
        break;
      case 'v':
        flag_container.v = 1;
        break;
      case 'c':
        flag_container.c = 1;
        break;
      case 'l':
        flag_container.l = 1;
        break;
      case 'n':
        flag_container.n = 1;
        break;
      default:
        fprintf(stderr, "Unknown flag\n");
        free_memory(patterns, count_templates);
        return 1;
    }
  }
  if (flag_container.c || flag_container.l) flag_container.n = 0;
  if (count_templates == 0 && optind < argc) {
    patterns = parse_templates(patterns, &count_templates, argv[optind]);
    if (patterns == NULL) return 1;
    optind++;
  }
  int file_count = argc - optind;
  if (file_count == 0) {
    fprintf(stderr, "Input the filename\n");
    free_memory(patterns, count_templates);
    return 1;
  } else {
    for (int i = optind; i < argc; i++) {
      file_handling(argv[i], patterns, count_templates, flag_container,
                    file_count);
    }
  }
  free_memory(patterns, count_templates);
  return 0;
}

int file_handling(const char *filename, char **patterns, int pattern_count,
                  flags flag_container, int file_count) {
  FILE *file = fopen(filename, "r");
  if (!file) {
    fprintf(stderr, "Error reading the file\n");
    return 1;
  }

  char line[MAX_LENGHT_STRING];
  int line_number = 0;
  int match_count = 0;
  while (fgets(line, sizeof(line), file) != NULL) {
    line_number++;
    int found = 0;

    for (int i = 0; i < pattern_count; i++) {
      if (find_string(line, patterns[i], flag_container)) {
        found = 1;
        break;
      }
    }

    if (found) {
      match_count++;
      if (!flag_container.c && !flag_container.l) {
        output(flag_container, line, (char *)filename, file_count, line_number);
      }
    }
  }
  fclose(file);
  if (flag_container.c || flag_container.l) {
    output_cl(flag_container, (char *)filename, file_count, match_count);
  }

  return 0;
}

void output(flags flag_container, char *line, char *filename, int file_number,
            int line_number) {
  if (file_number > 1) {
    if (flag_container.n) {
      printf("%s:%d:%s", filename, line_number, line);
    } else {
      printf("%s:%s", filename, line);
    }
  } else {
    if (flag_container.n) {
      printf("%d:%s", line_number, line);
    } else {
      printf("%s", line);
    }
  }
  if (!strchr(line, '\n')) printf("\n");
}

void output_cl(flags flag_container, char *filename, int file_number,
               int match_count) {
  if (flag_container.c && flag_container.l && match_count >= 1) {
    match_count = 1;
  }
  if (flag_container.c && file_number == 1) {
    printf("%d\n", match_count);
  } else if (flag_container.c) {
    printf("%s:%d\n", filename, match_count);
  }
  if (flag_container.l && match_count > 0) printf("%s\n", filename);
}

char **parse_templates(char **patterns, int *count_templates,
                       char *pattern_value) {
  char **new_patterns =
      realloc(patterns, (*count_templates + 1) * sizeof(char *));
  if (new_patterns == NULL) {
    fprintf(stderr, "Memory allocation failed for pattern storage\n");
    free_memory(patterns, *count_templates);
    return NULL;
  }

  new_patterns[*count_templates] = malloc(MAX_LENGHT_STRING);
  if (new_patterns[*count_templates] == NULL) {
    fprintf(stderr, "Memory allocation failed for pattern\n");
    free_memory(new_patterns, *count_templates);
    return NULL;
  }

  strcpy(new_patterns[*count_templates], pattern_value);
  (*count_templates)++;

  return new_patterns;
}

void free_memory(char **patterns, int count_templates) {
  for (int j = 0; j < count_templates; j++) free(patterns[j]);
  free(patterns);
}

int find_string(char *line, char *template, flags flag_container) {
  int same = 0;
  if (flag_container.i) {
    same = (strcasestr(line, template) != NULL);
  } else {
    same = (strstr(line, template) != NULL);
  }
  if (flag_container.v) {
    same = !same;
  }
  return same;
}